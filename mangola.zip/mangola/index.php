<html>
	<?php include "includes/cssheader.php";
	?>

	<body style="background-color: #2F3235">
		<?php include "includes/header_prelogin.php";
		?>
    	<div class="container" id="main_body">
    		<div class="row">
    			<div class="col-md-8 .margin-top-50">
    				<h1 class="text-white font-80px text-center"><b>Get the best mangoes at the cheapest price from Mangola</b></h1>
    			</div>
    			<div class="col-md-4 .margin-top-50">
    				<h1 class="text-white text-center">Login here to continue</h1><br>
    				<form class="form" action="login_user.php" method="POST">
    					<label class="text-white">Email</label><br>
    					<input type="email" name="user_em" class="form-control" placeholder="Enter your email" required><br>
    					<label class="text-white">Password</label><br>
    					<input type="password" class="form-control" name="user_password" required><br>
    					<input type="submit" value="Submit" class="btn btn-danger btn-block btn-lg">
    				</form>
    				<p class="text-white">Not a member? <a href="register.php">Register Here</a></p>
    			</div>
    		</div>
    	</div>
    </body>
</html>