<?php 
include "includes/dbconnect.php";
session_start();
$product_id=$_GET['product_id'];
$query="SELECT *FROM `products` WHERE `product_id` = $product_id";
$result=mysqli_query($connection,$query);
$row=mysqli_fetch_assoc($result); 
$product_name=$row['product_name'];
$product_desc=$row['product_desc'];
$product_image=$row['product_image'];
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>Starter Template for Bootstrap</title>
    <!-- Bootstrap core CSS -->
    <link href"../../dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css\style.css" rel="stylesheet">
    <link href="css\bootstrap.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="starter-template.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="starter-template.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

    <?php
      include "includes/header_postlogin.php";
    ?>

    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <?php
            if(isset($_GET['msg']))
            {
              if($_GET['msg']==1)
              {
                echo "<h4 style='color:red'>The product was added successfully to your wishlist!</h4>";
              }
              else if($_GET['msg']==2)
              {
                echo "<h4 style='color:red'>You have already added this product to your wishlist!</h4>";
              }
              else if($_GET['msg']==0)
              {
                echo "<h4 style='color:red'>Try Again! Some error occured!</h4>";
              }
            }
            ?>
            <?php
            if(isset($_GET['msg1']))
            {
              if($_GET['msg1']==1)
              {
                echo "<h4 style='color:red'>The product was added successfully to your cart!</h4>";
              }
              else if($_GET['msg1']==2)
              {
                echo "<h4 style='color:red'>You have already added this product to your cart!</h4>";
              }
              else
              {
                echo "<h4 style='color:red'>Try Again! Some error occured!</h4>";
              }
            }
            ?>

             <div class="col-md-6">
                  <img src="images/<?php echo $product_image;?>" class="img_size_lg">
                  </div>
                  <div class="col-md-6">
                    <h1><?php echo $product_name;?></h1>
                    <p><?php echo $product_desc;?></p>
                    <a href="add_to_wishlist.php?product_id=<?php echo $product_id;?>" class="btn btn-success btn-block">ADD 
                      TO WISHLIST</a><br>
                    <a href="add_to_cart.php?product_id=<?php echo $product_id;?>" class="btn btn-warning btn-block">ADD TO CART</a><br>
                  </div>     
      </div>
      <div class="row">
        <div class="col-md-8">
          <h2>Reviews</h2>
          <?php
            $query="SELECT * FROM `review` WHERE `product_id` ='$product_id' ";
            $result=mysqli_query($connection,$query);
          	$num_rows=mysqli_num_rows($result);
            $i=0;
            $solutions = array();
            while($row = mysqli_fetch_assoc($result)) {
              $solutions[] = $row['reviews'];
            }
            while($i<$num_rows)
            {
              echo $solutions[$i].'<br>';
              $i++;
            }
          ?>
        </div>
      </div>
    </div><!-- /.container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="../../dist/js/bootstrap.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>

