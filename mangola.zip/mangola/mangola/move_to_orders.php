<?php
include "includes/dbconnect.php";
session_start();
$product_id=$_GET['product_id'];
$user_id=$_SESSION['user_id'];
$query1="DELETE FROM `mangola-3138112c`.`cart` WHERE `product_id` LIKE '$product_id' AND `user_id` LIKE '$user_id'";
$result1=mysqli_query($connection,$query1);
if($result1)
{
  $query="INSERT INTO `mangola-3138112c`.`orders` (`order_id` ,`product_id` ,`user_id`) VALUES (NULL , '$product_id', '$user_id')";
  if(mysqli_query($connection,$query))
  {
    header('location:cart.php?product_id='.$product_id.'&msg2=1');
  }
}
else
{
  header('location:cart.php?product_id='.$product_id.'&msg2=0'); 
}
?>