<html>
  <?php 
    include "includes/cssheader.php";
    include "includes/dbconnect.php";
    session_start();
    $product_id=$_GET['product_id'];
  ?>
  <body style="background-color: #2F3235">
    <?php include "includes/header_postlogin.php";
    ?>
      <div class="container" id="main_body">
        <div class="row">
          <div class="col-md-12 .margin-top-50">
            <h1 class="text-white font-80px text-center"><b>ADD REVIEW</b></h1>
            <form action="finally.php" method="POST">
                <center><textarea rows="3" cols="80" name="review">Add Reviws Here</textarea></center>
                <input type="hidden" name="product_id" value="<?php echo $product_id;?>">
                <br><br><br>
                <input type="submit" class="btn btn-block btn-success">
            </form>
          </div>
          
        </div>
      </div>
    </body>
</html>