<?php
include "includes/dbconnect.php";
session_start();
$product_id=$_POST['product_id'];
$user_id=$_SESSION['user_id'];
$review=$_POST['review'];
$query="INSERT INTO `mangola-3138112c`.`review` (`r_id` ,`product_id` ,`user_id`,`reviews`) VALUES (NULL, '$product_id', '$user_id', '$review')";
if(mysqli_query($connection,$query))
{
  echo '<center><h1>REVIEW ADDED</h1></center>';
  echo '<center><h1><a href="products.php">GO TO PRODUCTS PAGE</a></h1></center>';
}
else
{
  echo '<center><h1>THERE HAS BEEN SOME ERROR';
}
?>