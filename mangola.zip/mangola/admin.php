<html>
	<head>
		<title>Add Product</title>
	</head>
	<body>
		<h2>Add product to database</h2>
		<form action="upload_product.php" method="POST" enctype="multipart/form-data">
			<label>Product Name</label><br>
			<input type="text" name="product_name"><br>
			<label>Product Price</label><br>
			<input type="number" name="product_price"><br>
			<label>Product Description</label>
			<textarea name="product_desc"></textarea><br>
			<label>Product Image</label><br>
			<input type="file" name="image"><br><br>
			<input type="submit" value="Add Product">
		</form>
	</body>
</html>