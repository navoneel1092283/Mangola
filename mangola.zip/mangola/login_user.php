<?php
include "includes/dbconnect.php";
session_start();
$email=$_POST['user_em'];
$password=$_POST['user_password'];

$query="SELECT *FROM `user` WHERE `email` LIKE '$email'AND `password` LIKE '$password'";
$result=mysqli_query($connection,$query);
$num_rows=mysqli_num_rows($result);
if($num_rows==1)
{
	$row=mysqli_fetch_assoc($result);
	$_SESSION['name']=$row['name'];
	$_SESSION['email']=$row['email'];
	$_SESSION['user_id']=$row['user_id'];
	header('location:products.php');
}
else
{
	header('location:index.php');
}
?>