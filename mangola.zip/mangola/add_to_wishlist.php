<?php
include "includes/dbconnect.php";
session_start();
$product_id=$_GET['product_id'];
$user_id=$_SESSION['user_id'];

$query1="SELECT * FROM `wishlist` WHERE `product_id`='$product_id' AND `user_id`='$user_id'";
$result1=mysqli_query($connection,$query1);

if(mysqli_num_rows($result1)==1)
{
  header('location: productdesc.php?product_id='.$product_id.'&msg=2');
}
else if(mysqli_num_rows($result1)==0)
{
  $query="INSERT INTO `mangola-3138112c`.`wishlist` (`wishlist_id` ,`product_id` ,`user_id`) VALUES (NULL, '$product_id', '$user_id')";
  if(mysqli_query($connection,$query))
  {
    header('location: productdesc.php?product_id='.$product_id.'&msg=1');
  }
  else
  {
    header('location: productdesc.php?product_id='.$product_id.'&msg=0'); 
  }
}
?>