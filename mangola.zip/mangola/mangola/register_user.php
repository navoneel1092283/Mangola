<?php
include "includes/dbconnect.php";

session_start();
//fetch user data
$name=$_POST['user_name'];
$email=$_POST['user_em'];
$password=$_POST['user_password'];
//push data to the db
$query="INSERT INTO `mangola-3138112c`.`user` (`user_id` ,`name` ,`email` ,`password`)
	    VALUES (NULL ,'$name','$email','$password')";
$result=mysqli_query($connection,$query);

if($result)
{
	//redirct
	$row=mysqli_fetch_assoc($result);
	$_SESSION['name']=$row['name'];
	$_SESSION['email']=$row['email'];
	header('location:login_user.php');
}
else
{
	//redirect
	header('location:register.php');
	echo "Some error occured";
}

?>