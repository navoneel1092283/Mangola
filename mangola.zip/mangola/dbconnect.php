<?php
//connect to the db

$connection=mysqli_connect("shareddb1c.hosting.stackcp.net","mangola-3138112c","xUXk+18BjRYP");

mysqli_select_db($connection,"mangola-3138112c");
?>